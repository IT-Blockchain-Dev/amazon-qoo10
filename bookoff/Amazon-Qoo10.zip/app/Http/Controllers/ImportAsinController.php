<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Qoo10\Api\Items\Goods;
use Qoo10\Api\Qoo10ApiProcessor;
use Qoo10\Api\Qoo10CertGenerator;

class ImportAsinController extends Controller
{
    //
    public function index(){
        // return view('front.ImportAsin');
        $key = 'BhiQeRsAhG2U11EPJ9tjQuxtmocnpd_g_2_iDPlGfd8xgv4_g_3_';
        $userId = 'mattya3585';
        $password = 'momotto110A';

        // $certGenerator = new Qoo10CertGenerator();
        // $cert = $certGenerator->certGenerate($key, $userId, $password);


        // $processor = new Qoo10ApiProcessor();
        // $processor->setCertificate($cert);

     
        // $url = 'http://api.qoo10.jp/GMKT.INC.Front.OpenApiService/APIList/CommonInfoAPIService.api/GetCatagoryListAll';
        // $data = array('key' => 'S5bnbfynQvOKjKOOi6rqr2kyaKwK_g_1__g_2_tyLHiSIJ7jifeGJ_g_2_tYHO_g_2_9lvlRVaBoXZdsquVBC3VERFI1swTZz8Jx_g_2_LTtMbTKziDCTpt62xvJx39u3jjQuqwyYOeGwPXWePCD', 'lang_cd' => 'en');
        
        // $ch = curl_init();

        // curl_setopt($ch, CURLOPT_URL,$url);
        // curl_setopt($ch, CURLOPT_POST, 1);
        // curl_setopt($ch, CURLOPT_POSTFIELDS,"key=S5bnbfynQvOKjKOOi6rqr2kyaKwK_g_1__g_2_tyLHiSIJ7jifeGJ_g_2_tYHO_g_2_9lvlRVaBoXZdsquVBC3VERFI1swTZz8Jx_g_2_LTtMbTKziDCTpt62xvJx39u3jjQuqwyYOeGwPXWePCD&lang_cd=en");
        // curl_setopt(
        //     $ch, 
        //     CURLOPT_HTTPHEADER, 
        //     array(
        //         'Content-Type: application/x-www-form-urlencoded', // for define content type that is json
        //     ));
        // curl_setopt($ch, CURLOPT_TIMEOUT, 3600000);
        // // In real life you should use something like:
        // // curl_setopt($ch, CURLOPT_POSTFIELDS, 
        // //          http_build_query(array('postvar1' => 'value1')));

        // // Receive server response ...
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // $server_output = curl_exec($ch);

        // curl_close ($ch);

        // // Further processing ...
        // if ($server_output == "OK") { } 
        // else { }
        $xml = simplexml_load_file("D:/category.xml");
        $id=1;
        foreach($xml->ResultObject->CommonCategoryInfo as $category){
            echo $id.",";
            echo $category->CATE_L_CD.",";
            echo $category->CATE_L_NM.",";
            echo $category->CATE_M_CD.",";
            echo $category->CATE_M_NM.",";
            echo $category->CATE_S_CD.",";
            echo $category->CATE_S_NM."<br>";
            $id++;
        }
        
       
    }

}
