<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ImportBlacklistController extends Controller
{
    //
    public function index(){
        return view('front.ImportBlackList');
    }
}
